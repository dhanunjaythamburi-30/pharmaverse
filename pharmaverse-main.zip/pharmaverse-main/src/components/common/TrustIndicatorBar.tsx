"use client";
import React from 'react';

const TrustIndicatorBar = () => {
  return null; // This hides the entire bar
};

export default TrustIndicatorBar;
