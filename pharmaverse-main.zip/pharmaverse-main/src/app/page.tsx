import LandingPageInteractive from './landing-page/components/LandingPageInteractive';

export default function Home() {
  return <LandingPageInteractive />;
}
